// let dino ={
//   jumping: true,
//   render: function(){
//     if(dino.jumping==true){
//       let html = `<div class="dino animated bounce"></div>
//                   <button class="jumping">JUMP</button>
//                   <button class="walking">WALK</button>`;
//       let div = document.getElementById('land');
//       div.innerHTML = html;
//     }
//     else{
//       let html = `<div class="dino "></div>`;
//       let div = document.getElementById('land');
//       div.innerHTML = html;
//     }
//   },
  let dino ={
  render: function(){
      let html = `<div class="dino"></div>`;
      let div = document.getElementById('land');
      div.innerHTML = html;
  },
  jumping: function(){
    let html = `<div class="dino animated bounce"></div>`;
    let div = document.getElementById('land');
    div.innerHTML = html;
  },
  walking: function(){
    alert(`OH SEEMS LIKE YOU BOUGHT THE FULL GAME FOR FULL  PRICE, BUT IF YOU WANT YOUR DINO WALK, YOU SHOLD BUY OUR SUPER DLC "THE WALKING DINO" ONLY FOR 49.99$!!!`)
  }
}
// dino.render();
